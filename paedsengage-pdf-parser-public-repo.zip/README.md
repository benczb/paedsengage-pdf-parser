# PaedsENGAGE PDF Parser Skill

An OpenClaw/Codex AgentSkill for converting PaedsENGAGE participating-clinic PDFs into structured JSON and CSV outputs for clinic-finder websites, review checklists, Excel, or dashboards.

## What it does

The bundled parser extracts clinic information from a PaedsENGAGE participating-clinics PDF and writes:

- `clinics.json`
- `clinics.csv`
- `clinic_hours.csv`
- `clinic_hours_blocks.csv`
- a text review dump for spot-checking extraction quality

It can also refresh a website data folder such as `site/data/clinics.json`.

## Repository contents

```text
.
├── SKILL.md
├── scripts/
│   └── parse_paedsengage_pdf.py
└── references/
    └── output-schema.md
```

## Requirements

- Python 3.10+
- `pdfplumber`
- `pandas`

Install dependencies in a virtual environment:

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install pdfplumber pandas
```

## Usage

From a project folder containing the source PDF:

```bash
python /path/to/paedsengage-pdf-parser/scripts/parse_paedsengage_pdf.py \
  --pdf data/paedsengage-clinics-YYYY-MM-DD.pdf \
  --out-dir data \
  --site-data-dir site/data
```

If you installed dependencies in the project virtual environment:

```bash
.venv/bin/python /path/to/paedsengage-pdf-parser/scripts/parse_paedsengage_pdf.py \
  --pdf data/paedsengage-clinics-YYYY-MM-DD.pdf \
  --out-dir data \
  --site-data-dir site/data
```

## Validation

Validate generated JSON:

```bash
python -m json.tool data/clinics.json >/dev/null
```

Quick count check:

```bash
python - <<'PY'
import json
from collections import Counter
clinics = json.load(open('data/clinics.json'))
print('clinics', len(clinics))
print('locations', len(set(c['location'] for c in clinics)))
print(Counter(c['location'] for c in clinics).most_common(10))
PY
```

## Notes

- PDF extraction is layout-sensitive. Always spot-check the generated outputs against the official source PDF.
- Generated Google Maps URLs are search URLs only. Permanently closed status, coordinates, and Google Place IDs require a separate Google Places audit.
- This repository does not include any official PDF by default. Add source PDFs only if you have the right to redistribute them.

## License

MIT License. See `LICENSE`.
