---
name: paedsengage-pdf-parser
description: Parse PaedsENGAGE participating clinic PDFs into structured JSON and CSV tables for websites, review checklists, Excel, or dashboards. Use when updating the PaedsEngage clinic finder from a new NUH/KKH PDF, converting a PaedsENGAGE PDF into clinic tables, refreshing `clinics.json`, or preparing Cloudflare Pages site data from the PDF.
---

# PaedsENGAGE PDF Parser

Use this skill to convert a PaedsENGAGE participating-clinics PDF into structured data tables.

## Workflow

1. Save or download the source PDF into the target project, usually `data/`.
2. Preserve existing outputs before overwriting them.
3. Run `scripts/parse_paedsengage_pdf.py` with the source PDF and output directory.
4. If a website uses `site/data/clinics.json`, pass `--site-data-dir site/data` so the site is refreshed too.
5. Validate the generated JSON and spot-check the CSV/table output for parsing errors.

## Command pattern

From a PaedsEngage project folder:

```bash
python /path/to/skill/scripts/parse_paedsengage_pdf.py \
  --pdf data/paedsengage-clinics-YYYY-MM-DD.pdf \
  --out-dir data \
  --site-data-dir site/data
```

If the project already has a virtual environment with `pdfplumber`, use it:

```bash
.venv/bin/python /path/to/skill/scripts/parse_paedsengage_pdf.py \
  --pdf data/paedsengage-clinics-YYYY-MM-DD.pdf \
  --out-dir data \
  --site-data-dir site/data
```

Do not install `pdfplumber` or other dependencies without user permission. If missing, ask before installing.

## Outputs

The parser writes:

- `clinics.json`
- `clinics.csv`
- `clinic_hours.csv`
- `clinic_hours_blocks.csv`
- a text review dump named after the source PDF

Read `references/output-schema.md` when you need field definitions or review guidance.

## Validation checklist

Run at minimum:

```bash
python -m json.tool data/clinics.json >/dev/null
```

Then inspect:

- total clinic count and location count
- a few high-volume locations such as Bedok/Tampines/Yishun
- the target location the user cares about, if any
- weird blank clinic names, addresses, or contacts

Example quick count:

```bash
python - <<'PY'
import json
from collections import Counter
clinics=json.load(open('data/clinics.json'))
print('clinics', len(clinics))
print('locations', len(set(c['location'] for c in clinics)))
print(Counter(c['location'] for c in clinics).most_common(10))
PY
```

## Notes

- This is a parser, not a source-of-truth validator. Tell users the data should be spot-checked because PDF extraction is layout-sensitive.
- The generated `google_maps_url` is a search URL only. Permanently closed status, coordinates, and place IDs require a separate Google Places audit.
